# 214-prac5
This repository contains the code for a Smart Home Automation System using 4-5 design patterns which are Composite, Adapter, Command, Observer, and Iterator. The project supports device control, legacy device integration, automation routines, sensor notifications, and efficient device management.
